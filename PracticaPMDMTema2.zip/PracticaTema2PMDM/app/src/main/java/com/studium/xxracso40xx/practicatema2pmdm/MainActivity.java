package com.studium.xxracso40xx.practicatema2pmdm;

import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner1;
    private Button boton;
    private TextView txtv;
    private EditText edit1;
    private EditText edit2;
    private EditText edit3;
    private String cadena;
    private RadioButton radio1;
    private RadioButton radio2;
    private RadioGroup grupo;
    private String cadena2;
    private String cadena3;
    private Switch sw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner1 = findViewById(R.id.spinner1);
        boton = (Button) findViewById(R.id.button);
        txtv = (TextView) findViewById(R.id.textView1);
        edit1= (EditText) findViewById(R.id.editText1);
        edit2= (EditText) findViewById(R.id.editText2);
        edit3= (EditText) findViewById(R.id.editText3);
        radio1= (RadioButton) findViewById(R.id.radioButton1);
        radio2=(RadioButton) findViewById(R.id.radioButton2);
        sw = (Switch) findViewById(R.id.switch1);
        grupo= (RadioGroup) findViewById(R.id.radioGroupp);
        //Creación de un ArrayList en el cual se encontrarán todos los Strings deseados.
        ArrayList<String> elementos = new ArrayList<String>();
        elementos.add("Casado");
        elementos.add("Separado");
        elementos.add("Viudo");
        elementos.add("Otro");
        ArrayAdapter adpt = new ArrayAdapter(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, elementos);
        spinner1.setAdapter(adpt);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //Conseguir elemento seleccionado del array, siendo elemento el string que está seleccionado actualmente del string
                String elemento = (String) spinner1.getAdapter().getItem(position);
                cadena=elemento;
                //Mostrar texto que diga que elementos hemos seleccionado del array
                Toast.makeText(MainActivity.this, "Seleccionaste: " + elemento, Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!edit1.getText().toString().isEmpty() && !edit2.getText().toString().isEmpty() && !edit3.getText().toString().isEmpty())
                {
                    edit1.setHintTextColor(getResources().getColor(R.color.gris));
                    edit2.setHintTextColor(getResources().getColor(R.color.gris));
                    edit3.setHintTextColor(getResources().getColor(R.color.gris));
                    txtv.setTextColor(getResources().getColor(R.color.gris));
                if (radio1.isChecked()) {
                    //cadena2 = "hombre";
                    cadena2=getResources().getString(R.string.hombre);
                } else if (radio2.isChecked()) {
                    cadena2 = getResources().getString(R.string.mujer);
                }
                //SEGUIR HACIENDO COMO LAS DE ARRIBA CON TODOS LOS STRINGS BORRAR ESTO DESPUÉS
                if (sw.isChecked()) {
                    cadena3 = "con hijos";
                } else {
                    cadena3 = "sin hijos";
                }
                int num1 = Integer.parseInt(edit3.getText().toString());
                if (num1 >= 18) {
                    txtv.setText(edit2.getText().toString() + ", " + edit1.getText().toString() + ", " + "mayor de edad" + ", " + cadena2 + " " + cadena + " y " + cadena3);
                } else if (num1 < 18) {
                    txtv.setText(edit2.getText().toString() + ", " + edit1.getText().toString() + ", " + "menor de edad" + ", " + cadena2 + " " + cadena + " y " + cadena3);
                }
            }
            if(edit1.getText().toString().isEmpty())
                {
                    edit1.setHint(getResources().getString(R.string.nombre_no));
                    edit1.setHintTextColor(getResources().getColor(R.color.rojo));
                }
                if(edit2.getText().toString().isEmpty())
                {
                    edit2.setHint("Necesita escribir sus apellidos");
                    edit2.setHintTextColor(getResources().getColor(R.color.rojo));
                }
                if(edit3.getText().toString().isEmpty())
                {
                    edit3.setHint("Necesita escribir su edad");
                    edit3.setHintTextColor(getResources().getColor(R.color.rojo));
                }
                if(grupo.getCheckedRadioButtonId()==-1)
                    {
                    txtv.setText("Usted debe seleccionar su género");
                }
            }
        });
    }
}
